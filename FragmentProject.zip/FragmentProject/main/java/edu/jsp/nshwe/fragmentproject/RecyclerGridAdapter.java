package edu.jsp.nshwe.fragmentproject;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by nshwe on 24-07-2018.
 */

public class RecyclerGridAdapter extends RecyclerView.Adapter<RecyclerGridAdapter.MyGridViewHolder> {

    private List<GridContents> gridContents;
    private Context context;

    public RecyclerGridAdapter(List<GridContents> gridContents, Context context) {
        this.gridContents = gridContents;
        this.context = context;
    }

    @NonNull
    @Override
    public MyGridViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.grid_contents,parent,false);
        MyGridViewHolder holder = new MyGridViewHolder(view);

        holder.relativeLayout.setOnClickListener((v) -> {
            Toast.makeText(context,holder.textView.getText(),Toast.LENGTH_SHORT).show();
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyGridViewHolder holder, int position) {
        holder.textView.setText(gridContents.get(position).getText());
        holder.imageView.setImageResource(gridContents.get(position).getImage());
        holder.relativeLayout.setBackgroundColor(gridContents.get(position).getColor());
    }

    @Override
    public int getItemCount() {
        return gridContents.size();
    }

    public class MyGridViewHolder extends RecyclerView.ViewHolder{

        private CardView cardView;
        private RelativeLayout relativeLayout;
        private ImageView imageView;
        private TextView textView;

        public MyGridViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.grid_cardview);
            relativeLayout = itemView.findViewById(R.id.grid_relativelayout);
            imageView = itemView.findViewById(R.id.grid_img_view);
            textView = itemView.findViewById(R.id.grid_text_view);
        }
    }
}
