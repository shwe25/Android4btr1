package edu.jsp.nshwe.fragmentproject;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by nshwe on 16-07-2018.
 */

public class RecyclerListAdapter extends RecyclerView.Adapter<RecyclerListAdapter.MyViewHoldrer> {

    private List<ContactDTO> dtos;
    private Context context;
    private Dialog dialog;

    public RecyclerListAdapter(List<ContactDTO> dtos, Context context) {
        this.dtos = dtos;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHoldrer onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_contents,parent,false);
        MyViewHoldrer holder = new MyViewHoldrer(view);
        holder.linearLayout.setOnClickListener((v) -> {
            displayDialog(holder);
        });

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHoldrer holder, int position) {
        holder.name.setText(dtos.get(position).getName());
        holder.number.setText(dtos.get(position).getNumber());
        holder.image.setImageResource(dtos.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return dtos.size();
    }

    public class MyViewHoldrer extends RecyclerView.ViewHolder{

        private LinearLayout linearLayout;
        private TextView name,number;
        private ImageView image,call_btn;

        public MyViewHoldrer(View itemView) {
            super(itemView);
            linearLayout = itemView.findViewById(R.id.list_linearLayout);
            name = itemView.findViewById(R.id.list_name);
            number = itemView.findViewById(R.id.list_number);
            image = itemView.findViewById(R.id.list_image);
            call_btn = itemView.findViewById(R.id.call_btn);

            call_btn.setOnClickListener((v1) -> {
                callAction(number.getText().toString());
            });
        }
    }

    private void displayDialog(MyViewHoldrer holder) {
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_content);

        TextView d_name = dialog.findViewById(R.id.dialog_name);
        TextView d_number = dialog.findViewById(R.id.dialog_phone);
        ImageView d_image = dialog.findViewById(R.id.dialog_img);
        Button d_call = dialog.findViewById(R.id.dialog_btn_call);
        Button d_msg = dialog.findViewById(R.id.dialog_btn_msg);

        d_name.setText(dtos.get(holder.getAdapterPosition()).getName());
        d_number.setText(dtos.get(holder.getAdapterPosition()).getNumber());
        d_image.setImageResource(dtos.get(holder.getAdapterPosition()).getImage());

        String phone_no = holder.number.getText().toString();
        d_call.setOnClickListener((v) -> {
            callAction(phone_no);
        });

        d_msg.setOnClickListener((v1) -> {
            msgAction(phone_no);
        });

        dialog.show();
    }

    private void callAction(String phone_no) {

        if(!TextUtils.isEmpty(phone_no)) {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone_no));
            context.startActivity(intent);
        }else
            Toast.makeText(context,"Number not found",Toast.LENGTH_SHORT).show();
    }

    private void msgAction(String phone_no) {

        if (!TextUtils.isEmpty(phone_no)) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:" + phone_no));
            intent.putExtra("sms_body","My Msg");
            context.startActivity(intent);
        }else
            Toast.makeText(context,"Number not found",Toast.LENGTH_SHORT).show();
    }
}
