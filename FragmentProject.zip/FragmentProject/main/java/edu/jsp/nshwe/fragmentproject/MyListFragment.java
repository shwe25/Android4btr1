package edu.jsp.nshwe.fragmentproject;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class MyListFragment extends Fragment {


    private View view;
    private RecyclerView recyclerView;
    private List<ContactDTO> dtos;

    public List<ContactDTO> getDtos(){
        return dtos;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dtos = new ArrayList<>();
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","7685439859",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8752984795",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","",R.mipmap.ic_launcher_round));
        dtos.add(new ContactDTO("ABc","8787768798",R.mipmap.ic_launcher_round));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.fragment_my_list, container, false);
        recyclerView = view.findViewById(R.id.recyclerListView);
        RecyclerListAdapter recyclerListAdapter = new RecyclerListAdapter(dtos,getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(recyclerListAdapter);
        return view;
    }

}
