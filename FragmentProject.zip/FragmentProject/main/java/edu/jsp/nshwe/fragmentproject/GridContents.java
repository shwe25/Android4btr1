package edu.jsp.nshwe.fragmentproject;

import android.graphics.Color;

/**
 * Created by nshwe on 24-07-2018.
 */

public class GridContents {

    private String text;
    private int image;
    private int color;

    public GridContents(String text, int image, int color) {
        this.text = text;
        this.image = image;
        this.color = color;
    }

    public String getText() {
        return text;
    }

    public int getImage() {
        return image;
    }

    public int getColor() {
        return color;
    }
}
