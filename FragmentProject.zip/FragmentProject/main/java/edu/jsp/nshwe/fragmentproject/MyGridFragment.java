package edu.jsp.nshwe.fragmentproject;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class MyGridFragment extends Fragment {

    private List<ContactDTO> dtoList;
    private List<GridContents> gridContents;
    private RecyclerView recyclerView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*MyListFragment fragment = getFragmentManager().;
        dtoList = fragment.getDtos();*/
        
        gridContents = new ArrayList<>();
        gridContents.add(new GridContents("Image 1",R.drawable.ic_call_black_24dp, Color.BLUE));
        gridContents.add(new GridContents("Image 2",R.drawable.ic_grid, Color.CYAN));
        gridContents.add(new GridContents("Image 3",R.drawable.ic_list, Color.DKGRAY));
        gridContents.add(new GridContents("Image 4",R.drawable.ic_message_black, Color.LTGRAY));
        gridContents.add(new GridContents("Image 5",R.drawable.ic_call_black_24dp, Color.MAGENTA));
        gridContents.add(new GridContents("Image 6",R.drawable.ic_grid, Color.GREEN));
        gridContents.add(new GridContents("Image 7",R.drawable.ic_list, Color.RED));
        gridContents.add(new GridContents("Image 8",R.drawable.ic_message_black, Color.YELLOW));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_my_grid, container, false);
        recyclerView = view.findViewById(R.id.recyclerGridView);
        RecyclerGridAdapter adapter = new RecyclerGridAdapter(gridContents,getContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        return view;
    }
}
