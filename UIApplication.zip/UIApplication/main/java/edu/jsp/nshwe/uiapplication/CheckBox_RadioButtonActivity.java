package edu.jsp.nshwe.uiapplication;

import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class CheckBox_RadioButtonActivity extends AppCompatActivity {

    private CheckBox java,j2ee,android,sql,web,frameworks;
    private Button showFee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkbox__radiobutton);

        showFee = findViewById(R.id.showfee_btn);
        java = findViewById(R.id.java_cb);
        j2ee = findViewById(R.id.j2ee_cb);
        android = findViewById(R.id.android_cb);
        sql = findViewById(R.id.sql_cb);
        web = findViewById(R.id.web_cb);
        frameworks = findViewById(R.id.framework_cb);

        showFee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAction();
            }
        });
    }

    private void setAction() {
        int total = 0;
        Resources resources = getResources();
        StringBuilder builder = new StringBuilder("Fee Details");
        if(java.isChecked()){
            builder.append("\n "+resources.getString(R.string.java)+" - "+resources.getInteger(R.integer.javaf));
            total += resources.getInteger(R.integer.javaf);
        }
        if(j2ee.isChecked()){
            builder.append("\n "+resources.getString(R.string.j2ee)+" - "+resources.getInteger(R.integer.j2eef));
            total += resources.getInteger(R.integer.j2eef);
        }
        if(android.isChecked()){
            builder.append("\n "+resources.getString(R.string.android)+" - "+resources.getInteger(R.integer.androidf));
            total += resources.getInteger(R.integer.androidf);
        }
        if(sql.isChecked()){
            builder.append("\n "+resources.getString(R.string.sql)+" - "+resources.getInteger(R.integer.sqlf));
            total += resources.getInteger(R.integer.sqlf);
        }
        if(web.isChecked()){
            builder.append("\n "+resources.getString(R.string.web)+" - "+resources.getInteger(R.integer.webf));
            total += resources.getInteger(R.integer.webf);
        }
        if(frameworks.isChecked()){
            builder.append("\n "+resources.getString(R.string.frameworks)+" - "+resources.getInteger(R.integer.frameworks));
            total += resources.getInteger(R.integer.frameworks);
        }
        builder.append("\n------------------------");
        builder.append("\nTotal\t-\t"+total);
        if(total > 0)
            showDetails(builder.toString());
        else
            showDetails("Choose any Course");
    }

    private void showDetails(String details) {
        Toast.makeText(getBaseContext(),details,Toast.LENGTH_LONG).show();
    }
}
