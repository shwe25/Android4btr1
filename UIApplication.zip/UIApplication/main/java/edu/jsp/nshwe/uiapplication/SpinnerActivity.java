package edu.jsp.nshwe.uiapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;

public class SpinnerActivity extends AppCompatActivity {

    private MultiAutoCompleteTextView multiAutoCompleteTextView;
    private AutoCompleteTextView autoCompleteTextView;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);

        multiAutoCompleteTextView = findViewById(R.id.multiAutoCtv);
        autoCompleteTextView = findViewById(R.id.autoCtv);
        spinner = findViewById(R.id.spinner);

        spinnerAction();
        autoCompleteTextViewAction();
        multiAutoCompleteTextViewAction();
    }

    private void multiAutoCompleteTextViewAction() {
        String[] textMsg = getResources().getStringArray(R.array.textMsg);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item,textMsg);
        multiAutoCompleteTextView.setAdapter(adapter);
        multiAutoCompleteTextView.setThreshold(1);
        multiAutoCompleteTextView.setTokenizer(new SpaceTokenizer());
    }

    private void autoCompleteTextViewAction() {
        String dept[] = getResources().getStringArray(R.array.dept);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1,dept);

        autoCompleteTextView.setAdapter(adapter);
        autoCompleteTextView.setThreshold(2);
    }

    private void spinnerAction() {

        String country[] = getResources().getStringArray(R.array.country);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_dropdown_item,country);

        adapter.setDropDownViewResource(android.R.layout.simple_gallery_item);

        spinner.setAdapter(adapter);
    }
}
