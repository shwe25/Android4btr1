package edu.jsp.nshwe.uiapplication;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private Button cb_ex,btn_ex,spinner_ex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb_ex = findViewById(R.id.cb_rd_btn_ex);
        btn_ex = findViewById(R.id.btn_ex);
        spinner_ex = findViewById(R.id.spinner_ex);

        cb_ex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent
                        (MainActivity.this,CheckBox_RadioButtonActivity.class);
                startActivity(intent);
            }
        });

        btn_ex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,ButtonActivity.class));
            }
        });
        spinner_ex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,SpinnerActivity.class));
            }
        });
    }
}
