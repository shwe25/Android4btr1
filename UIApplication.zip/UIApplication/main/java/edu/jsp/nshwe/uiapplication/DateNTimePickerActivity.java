package edu.jsp.nshwe.uiapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateNTimePickerActivity extends AppCompatActivity {

    private EditText date_et,time_et;
    private ImageView date_img,time_img;
    GregorianCalendar calendar = new GregorianCalendar();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_ntime_picker);

        date_et = findViewById(R.id.date_et);
        date_img = findViewById(R.id.date_img);
        time_et = findViewById(R.id.time_et);
        time_img = findViewById(R.id.time_img);

        date_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dateDialog();
            }
        });
        time_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timeDialog();
            }
        });
    }

    private void timeDialog() {
        int hr = calendar.get(Calendar.HOUR);
        int min = calendar.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
               time_et.setText(hourOfDay+":"+minute);
            }
        },hr,min,false);
        timePickerDialog.show();
    }

    private void dateDialog() {

        int date = calendar.get(Calendar.DATE);
        int mnth = calendar.get(Calendar.MONTH);
        int yr = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //date_et.setEnabled(true);
                date_et.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        },yr,mnth,date);
        datePickerDialog.show();
    }
}
