package edu.jsp.nshwe.jsonapp;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by nshwe on 12-07-2018.
 */

public class NetworkTask extends AsyncTask {

    private String location;
    private TextView textView;
    private ProgressBar progressBar;
    private String response = "";
    String result;

    public NetworkTask(String location, TextView textView, ProgressBar progressBar) {
        this.location = "https://maps.googleapis.com/maps/api/geocode/json?address="+location;
        this.textView = textView;
        this.progressBar = progressBar;
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            URL url = new URL(location);
            HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
            InputStream inputStream = httpsURLConnection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while (line != null){
                line = reader.readLine();
                response += line;
            }
            Log.d("Response",response);
            JSONObject object = new JSONObject(response);
            result = "Address : \n"+object.getJSONArray("results").getJSONObject(0)
                    .getString("formatted_address");
        }  catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            try {
                JSONObject object = new JSONObject(response);
                result = object.getString("error_message");
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        progressBar.setVisibility(View.GONE);
        textView.setText(result);
    }
}
