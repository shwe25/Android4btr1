package edu.jsp.nshwe.jsonapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private SearchView searchView;
    private Button button;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        searchView = findViewById(R.id.searchView);
        button = findViewById(R.id.fetch_btn);
        progressBar = findViewById(R.id.progerssBar);

        button.setOnClickListener((View v) -> {
            fetchAddress();
        });
    }

    private void fetchAddress() {
        String location = searchView.getQuery().toString();
        NetworkTask networkTask = new NetworkTask(location,textView,progressBar);
        progressBar.setVisibility(View.VISIBLE);
        networkTask.execute();
    }
}
