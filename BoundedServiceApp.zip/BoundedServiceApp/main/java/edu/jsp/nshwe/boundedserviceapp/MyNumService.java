package edu.jsp.nshwe.boundedserviceapp;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.Random;

public class MyNumService extends Service {

    private MyBinder binder = new MyBinder();
    private Random random = new Random();


    public class MyBinder extends Binder{
        public MyNumService getInstance(){
            return MyNumService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("onCreate","Service Created");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d("onBind","Service Binded");
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("onUnBind","Service UnBinded");
        return super.onUnbind(intent);
    }

    public Integer generateNum(){
        return random.nextInt(1000);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Service Destroyed");
    }
}
