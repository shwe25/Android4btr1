package edu.jsp.nshwe.fragmentapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class FragmentText extends Fragment {

    TextView state_text,famous_text;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_text, container, false);
        state_text = view.findViewById(R.id.state_text);
        famous_text = view.findViewById(R.id.famous_text);
        return view;
    }

    public void setTextFields(String state,String famous){
        state_text.setText(state);
        famous_text.setText("Famous for : \n"+famous);
    }
}
