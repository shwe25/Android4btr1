package edu.jsp.nshwe.sqliteapp;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.File;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText ename,eno,esalary;
    private Button add,view,delete,update,viewAll;
    private SQLiteDatabase database;
    private final String TABLE_NAME = "emp";
    private final String ENO_COL = "eno";
    private final String ENAME_COL = "ename";
    private final String ESAL_COL = "esalary";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creating DataBase - emp_db
        //File file = new File("emp_db");

        database = openOrCreateDatabase("emp_db", Context.MODE_PRIVATE,null);

        //Creating Table
        database.execSQL("CREATE TABLE IF NOT EXISTS emp" +
                "("+ENO_COL+" VARCHAR,"+ENAME_COL+" VARCHAR,"+ESAL_COL+" VARCHAR)");

        ename = findViewById(R.id.ename);
        eno = findViewById(R.id.eno);
        esalary = findViewById(R.id.eSalary);
        add = findViewById(R.id.add);
        view = findViewById(R.id.view);
        delete = findViewById(R.id.delete);
        update = findViewById(R.id.update);
        viewAll = findViewById(R.id.viewAll);

        add.setOnClickListener(this);
        view.setOnClickListener(this);
        delete.setOnClickListener(this);
        update.setOnClickListener(this);
        viewAll.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add : add(); break;
            case R.id.view : view(); break;
            case R.id.update : modify(); break;
            case R.id.delete: remove(); break;
            case R.id.viewAll : viewAll(); break;
        }
    }

    private void viewAll() {
        Cursor cursor = database.rawQuery("Select * from "+TABLE_NAME,null);
        StringBuilder builder = new StringBuilder();
        int i = 0;
        while (cursor.moveToNext()){
            i++;
            builder.append("\nEno : "+cursor.getString(0));
            builder.append("\nEname : "+cursor.getString(1));
            builder.append("\nESalary : "+cursor.getString(2));
            builder.append("\n---------------------------");
        }
        if(i > 0)
            display("Success",builder.toString());
        else
            display("Error","No records in "+TABLE_NAME);
    }

    private void remove() {
        if(eno.getText().toString().trim().length() == 0 )
            display("Error","Eno is mandatory");
        else{
            String where = ENO_COL+"="+eno.getText().toString();
            int i = database.delete(TABLE_NAME,where,null);
            if(i > 0 )
                display("Success","Row Deleted");
            else
                display("Error","No row affected");
        }
        clearFields();
    }
    private void modify() {
        if(ename.getText().toString().trim().length() == 0 ||
                eno.getText().toString().trim().length() == 0 ||
                esalary.getText().toString().trim().length() == 0 )
            display("Error","All fields are mandatory");
        else{
            ContentValues values = new ContentValues();
            values.put(ENAME_COL,ename.getText().toString());
            values.put(ESAL_COL,esalary.getText().toString());
            String where = ENO_COL+"="+eno.getText();
            int i = database.update(TABLE_NAME,values,where,null);
            if (i > 0)
                display("Success","Row Updated");
            else
                display("Error","No row affected");
        }
        clearFields();
    }

    private void view() {
        if(eno.getText().toString().trim().length() == 0 )
            display("Error","Eno is mandatory");
        else {
            String  where = " where "+ENO_COL+" = "+eno.getText();
            Cursor cursor = database.rawQuery("Select * from "+TABLE_NAME+where,null);
            if(cursor.moveToNext()){
                StringBuilder builder = new StringBuilder();
                builder.append("\nEno : "+cursor.getString(0));
                builder.append("\nEname : "+cursor.getString(1));
                builder.append("\nESalary : "+cursor.getString(2));
                display("Success",builder.toString());
            }else
                display("Error","No such Record");
        }
    }

    private void add() {
        if(ename.getText().toString().trim().length() == 0 ||
            eno.getText().toString().trim().length() == 0 ||
            esalary.getText().toString().trim().length() == 0 )
            display("Error","All the Fields are mandatory to insert");
        else{
            ContentValues values = new ContentValues();
            values.put(ENO_COL,eno.getText().toString());
            values.put(ENAME_COL,ename.getText().toString());
            values.put(ESAL_COL,esalary.getText().toString());
            long i = database.insert(TABLE_NAME,null,values);
            if(i > 0)
                display("Success","One Row inserted");
            else
                display("Error","No Row affected");
        }
        clearFields();
    }

    private void clearFields() {
        ename.setText("");
        eno.setText("");
        esalary.setText("");
    }

    private void display(String status, String s) {
        new AlertDialog.Builder(this)
                .setCancelable(true)
                .setTitle(status)
                .setMessage(s)
                .show();
    }
}
