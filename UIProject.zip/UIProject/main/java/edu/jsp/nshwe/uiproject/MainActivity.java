package edu.jsp.nshwe.uiproject;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button,next;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        textView = findViewById(R.id.textview);
        next = findViewById(R.id.next_btn);

        Log.d("onCreate","Activity Created");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setBroadCast();
            }
        });

        next.setOnClickListener((v) -> {
            Intent intent = new Intent(this,Main2Activity.class);
            intent.putExtra("MyInfo","My First Intent");
            startActivity(intent);
        });
    }

    private void setBroadCast() {

       /* IntentFilter intentFilter = new IntentFilter(getPackageName()+".MY_ACTION");
        registerReceiver(new MyReceiver(),intentFilter);*/

        Intent intent = new Intent(this,MyReceiver.class);
        intent.setAction("MY_ACTION");
        sendBroadcast(intent);
    }


}

