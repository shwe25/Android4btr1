package edu.jsp.nshwe.dynamicfragmentapp;

/**
 * Created by nshwe on 16-07-2018.
 */

public class GridData {

    private String image_name;
    private int image;
    private int backgroundcolor;

    public GridData(String image_name, int image, int backgroundcolor) {
        this.image_name = image_name;
        this.image = image;
        this.backgroundcolor = backgroundcolor;
    }

    public String getImage_name() {
        return image_name;
    }

    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getBackgroundcolor() {
        return backgroundcolor;
    }

    public void setBackgroundcolor(int backgroundcolor) {
        this.backgroundcolor = backgroundcolor;
    }
}
