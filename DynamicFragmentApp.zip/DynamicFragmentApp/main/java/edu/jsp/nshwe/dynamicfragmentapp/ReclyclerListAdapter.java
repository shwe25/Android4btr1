package edu.jsp.nshwe.dynamicfragmentapp;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Created by nshwe on 09-07-2018.
 */

public class ReclyclerListAdapter extends RecyclerView.Adapter<ReclyclerListAdapter.MyViewHolder> {

    private Dialog dialog;
    private Activity context;
    private List<ContactData> dataList;

    private static final int MY_PERMISSIONS_REQUEST_CALL_PHONE = 1;

    public ReclyclerListAdapter(Activity context, List<ContactData> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_contents, parent, false);
        final MyViewHolder viewHolder = new MyViewHolder(view);

        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_contents);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        viewHolder.linearLayout.setOnClickListener((v) -> {
            dialogAction(viewHolder);
        });

        return viewHolder;
    }

    private void dialogAction(MyViewHolder viewHolder) {
        TextView d_name = dialog.findViewById(R.id.dialog_name);
        TextView d_number = dialog.findViewById(R.id.dialog_phone);
        ImageView d_image = dialog.findViewById(R.id.dialog_img);
        Button d_call = dialog.findViewById(R.id.dialog_btn_call);
        Button d_msg = dialog.findViewById(R.id.dialog_btn_msg);

        String phone_no = viewHolder.number.getText().toString();
        //call button
        d_call.setOnClickListener((view1) -> {
            dialAction(phone_no);
            //callAction(phone_no);
        });

        d_msg.setOnClickListener((view) -> {
            String msg = "smsto:" + phone_no;
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse(msg));
            intent.putExtra("sms_body","my new msg");
            context.startActivity(intent);
        });

        d_name.setText(dataList.get(viewHolder.getAdapterPosition()).getName());
        d_number.setText(dataList.get(viewHolder.getAdapterPosition()).getNumber());
        d_image.setImageResource(dataList.get(viewHolder.getAdapterPosition()).getImage());

        dialog.show();
    }


    private void dialAction(String phone_no) {
        if (!TextUtils.isEmpty(phone_no)) {
            String dial = "tel:" + phone_no;
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(dial));
            context.startActivity(intent);
        }
    }

    private void callAction(String phone_no) {
        if (!TextUtils.isEmpty(phone_no)) {
            String dial = "tel:" + phone_no;
            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse(dial));

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                Log.d("Permission","Denied");

                return;
            }
            context.startActivity(intent);
        }
    }
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(dataList.get(position).getName());
        holder.number.setText(dataList.get(position).getNumber());
        holder.imageView.setImageResource(dataList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout linearLayout;
        private ImageView imageView,dial_img;
        private TextView name,number;


        public MyViewHolder(View itemView) {
            super(itemView);
            linearLayout = itemView.findViewById(R.id.list_linearLayout);
            imageView = itemView.findViewById(R.id.list_image);
            dial_img = itemView.findViewById(R.id.list_call);
            name = itemView.findViewById(R.id.list_name);
            number = itemView.findViewById(R.id.list_number);

            dial_img.setOnClickListener((view) -> {
                dialAction(number.getText().toString());
                //callAction(number.getText().toString());
            });
        }
    }
}
