package edu.jsp.nshwe.dynamicfragmentapp;


import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class MyGridFragment extends Fragment {

    private View view;
    private List<GridData> gridData;
    private RecyclerView recyclerView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gridData = new ArrayList<>();
        gridData.add(new GridData("Image1",R.drawable.ic_call, Color.BLUE));
        gridData.add(new GridData("Image2",R.drawable.ic_message_black, Color.CYAN));
        gridData.add(new GridData("Image3",R.drawable.ic_list, Color.DKGRAY));
        gridData.add(new GridData("Image4",R.drawable.ic_grid, Color.GRAY));
        gridData.add(new GridData("Image5",R.drawable.ic_list_black_24dp, Color.GREEN));
        gridData.add(new GridData("Image6",R.drawable.ic_call, Color.MAGENTA));
        gridData.add(new GridData("Image7",R.drawable.ic_list, Color.LTGRAY));
        gridData.add(new GridData("Image8",R.drawable.ic_grid, Color.RED));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_my_grid, container, false);
        recyclerView = view.findViewById(R.id.recyclerGridView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        RecyclerGridAdapter adapter = new RecyclerGridAdapter(gridData,getContext());
        recyclerView.setAdapter(adapter);
        return view;
    }

}
