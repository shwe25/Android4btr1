package edu.jsp.nshwe.dynamicfragmentapp;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class MyListFragment extends Fragment {

    private List<ContactData> dataList;
    private RecyclerView recyclerView;
    private View view;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataList = new ArrayList<>();
        dataList.add(new ContactData("abc","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("bcd","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("xji","03859749879",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("ndbj","845943",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("jkdhjkafh","85789457",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("euhf","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("abc","8957654872",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("kdnfj","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("ueydu","838468765",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("jdhf","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("cmnv","8476585987",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("mnd","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("iueuif","123456789",R.mipmap.ic_launcher_round));
        dataList.add(new ContactData("abc","123456789",R.mipmap.ic_launcher_round));
        Collections.sort(dataList);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_my_list, container,false);
        recyclerView = view.findViewById(R.id.recycler_listView);
        ReclyclerListAdapter adapter = new ReclyclerListAdapter(getActivity(), dataList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);
        return view;
    }

}
