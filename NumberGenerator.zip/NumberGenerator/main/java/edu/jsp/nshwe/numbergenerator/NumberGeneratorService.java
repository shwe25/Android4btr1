package edu.jsp.nshwe.numbergenerator;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.Random;

public class NumberGeneratorService extends Service {

    private Random random = new Random();
    private NumberBinder numberBinder = new NumberBinder();
    @Override
    public IBinder onBind(Intent intent) {

        Log.d("onBind","Service Binded");
        return numberBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("onUnBind","Service un+Binded");
        return super.onUnbind(intent);

    }

    public int generateNumber(){
        Log.d("Thread number generator",Thread.currentThread().getName());
        return random.nextInt(1000);
    }

    public class NumberBinder extends Binder{
        public NumberGeneratorService getInstance(){
            return NumberGeneratorService.this;
        }
    }

    @Override
    public void onDestroy() {
        Log.d("onDestroy","Service Destroyed");
        super.onDestroy();
    }
}
