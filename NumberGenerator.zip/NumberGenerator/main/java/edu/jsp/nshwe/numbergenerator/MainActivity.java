package edu.jsp.nshwe.numbergenerator;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.HttpAuthHandler;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button next;
    private TextView textView;
    private NumberGeneratorService generatorService;
    private boolean bounded;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d("onServiceConnected","service connected");
            NumberGeneratorService.NumberBinder binder = (NumberGeneratorService.NumberBinder) service;
            generatorService = binder.getInstance();
            bounded = true;
            displayNumber();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d("onServiceDisConnected","service disconnected");
            bounded = false;
        }
    };

    private void displayNumber() {
        Log.d("displayNumber","Number displayed");
        Log.d("Thread Display",Thread.currentThread().getName());
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                if(bounded){
                    textView.setText(generatorService.generateNumber()+"");
                    handler.postDelayed(this,1000);
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("Thread Activity",Thread.currentThread().getName());
        Log.d("onCreate","Activity Created");
        next = findViewById(R.id.next);
        textView = findViewById(R.id.number_view);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,NextActivity.class));
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("onStart","Activity Started");
        Intent intent = new Intent(this,NumberGeneratorService.class);
        bindService(intent,connection,BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        Log.d("onStop","Activity stopped");
        super.onStop();
        unbindService(connection);
        bounded = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Activity Destroyed");
    }
}
