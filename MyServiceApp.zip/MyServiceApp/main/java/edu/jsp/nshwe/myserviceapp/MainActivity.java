package edu.jsp.nshwe.myserviceapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("onCreate","Activity Created");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.service_btn);

        button.setOnClickListener((v) -> {
            Log.d("Button ","Button Clicked");
            Intent intent = new Intent(this,MyIntentService.class);
            intent.putExtra("MyMsg","My Intent Service");
            startService(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Activity Destroyed");
    }
}
