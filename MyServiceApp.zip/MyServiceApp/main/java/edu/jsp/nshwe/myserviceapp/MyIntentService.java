package edu.jsp.nshwe.myserviceapp;

import android.app.IntentService;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;


public class MyIntentService extends IntentService {

    public MyIntentService() {
        super("MyIntentService");
    }
    private Handler handler;

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        Log.d("onStartCommand ","Service Started");

        handler = new Handler();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("onHandleIntent ","Intent Received");

        synchronized (this){
            try {
                wait(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        String msg = intent.getStringExtra("MyMsg");
        displayMsg(msg);
    }

    private void displayMsg(String msg) {
        handler.post(() -> {
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
        });

        Log.d("My Msg",msg);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Service Destroyed");
    }
}
