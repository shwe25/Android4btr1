package edu.jsp.nshwe.loginwithsp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;

public class LoginActivity extends AppCompatActivity {

    private EditText userId,password;
    private Button login;
    private CheckBox rememberMe;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private File file;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userId = findViewById(R.id.user_id);
        password = findViewById(R.id.password);
        login = findViewById(R.id.button);
        rememberMe = findViewById(R.id.remember);

        sharedPreferences = getSharedPreferences("MyCredentials", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        file = getDir("MyCredential",Context.MODE_PRIVATE);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        furtherLogin();
    }

    private void furtherLogin() {
        if(sharedPreferences.getBoolean("checked",false)){
            //userId.setText(sharedPreferences.getString("user",null));
            //password.setText(sharedPreferences.getString("pswd",null));
            nextActivity();
        }
    }

    private void login() {
        String user = userId.getText().toString();
        String pswd = password.getText().toString();

        if(user.equals("iam") && pswd.equals("1234")){
            if(rememberMe.isChecked())
                saveCredential(user, pswd);

            nextActivity();
        }else {
            Toast.makeText(this,"Invalid Credential",Toast.LENGTH_SHORT).show();
        }
    }

    private void nextActivity() {
        startActivity(new Intent(this,MainActivity.class));
        finish();
    }

    private void saveCredential(String user, String pswd) {
        editor.putBoolean("checked",true);
        editor.putString("user",user);
        editor.putString("pswd",pswd);
        editor.commit();
        Log.d("File Path",file.toString());
        Toast.makeText(this,file.toString(),Toast.LENGTH_LONG).show();
    }
}
