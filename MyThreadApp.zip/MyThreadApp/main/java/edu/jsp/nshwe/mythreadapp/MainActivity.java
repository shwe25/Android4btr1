package edu.jsp.nshwe.mythreadapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);

        Log.d("Thread name",Thread.currentThread().getName());

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Log.d("Runnable Thread",Thread.currentThread().getName());
                try {
                    for (int i = 0;i<10;i++) {
                        Thread.sleep(0);
                        Log.d("Runnable", "Anonymous run()...");
                        textView.setText(i+"");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        Thread t = new Thread(runnable);
        t.setName("RunnableT");
        t.start();
    }
}
