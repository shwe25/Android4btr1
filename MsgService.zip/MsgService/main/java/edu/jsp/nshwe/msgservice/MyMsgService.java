package edu.jsp.nshwe.msgservice;

import android.app.IntentService;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;


public class MyMsgService extends IntentService {

    Handler handler;
    public MyMsgService(){super("MyMsgService");}

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        Log.d("onStartCommand Thread",Thread.currentThread().getName());
        handler = new Handler();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("onHandleIntent Thread",Thread.currentThread().getName());
        Log.d("onHandleIntent","recieving");
       synchronized (this) {
           try {
               wait(10000);
           } catch (InterruptedException e) {
               e.printStackTrace();
           }
       }
       String text1 = intent.getStringExtra("msg");
       String text2 = intent.getStringExtra("msg1");
       dispText(text1+"\n"+text2);
    }

    private void dispText(final String s) {
        Log.d("dispText Thread",Thread.currentThread().getName());
        handler.post(new Runnable() {
            @Override
            public void run() {
                Log.d("run Thread",Thread.currentThread().getName());
                Log.d("dispText",s);
                Toast.makeText(MyMsgService.this,s,Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy s Thread",Thread.currentThread().getName());
        Log.d("onDestroy","Service destroyed");
    }
}
