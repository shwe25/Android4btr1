package edu.jsp.nshwe.msgservice;

/**
 * Created by nshwe on 22-06-2018.
 */

public class MyThread implements Runnable {
    @Override
    public void run() {

    }

    Thread thread = new Thread(new MyThread());


}
