package edu.jsp.nshwe.broadcast;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAction();
            }
        });
        IntentFilter intentFilter = new IntentFilter("android.intent.action.AIRPLANE_MODE");
        intentFilter.addAction("android.intent.action.ACTION_SHUTDOWN");

        MyReceiver receiver = new MyReceiver();
        registerReceiver(receiver,intentFilter);
    }

    private void setAction() {
        Intent intent = new Intent();
        intent.setAction(getPackageName()+".SOME_ACTION");
        sendBroadcast(intent);
    }
}
