package edu.jsp.nshwe.ipcdemo;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.Random;

public class MyNumService extends Service {

    private MyBinder binder = new MyBinder();
    private Random random = new Random();

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    class MyBinder extends Binder{
        public MyNumService getInstance(){
            return MyNumService.this;
        }
    }

    public int generateNum(){
        return random.nextInt(1000);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Tag","Unbind Service");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Tag","Service Destroyed");
    }
}
