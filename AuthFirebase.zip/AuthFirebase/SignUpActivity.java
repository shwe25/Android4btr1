package com.example.nshwe.firebasedbapp.authentication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nshwe.firebasedbapp.MainActivity;
import com.example.nshwe.firebasedbapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener{

    private FirebaseAuth mAuth;
    private EditText user_et, pswd_et, confirmPswd_et;
    private Button signup_btn;
    private TextView signin_btn;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_up);

        user_et = findViewById(R.id.signup_email);
        pswd_et = findViewById(R.id.signup_pswd);
        confirmPswd_et = findViewById(R.id.singup_retype_pswd);
        signup_btn = findViewById(R.id.signup_btn);
        signin_btn = findViewById(R.id.signup_login_btn);
        progressBar = findViewById(R.id.progressbar);

        signup_btn.setOnClickListener(this);
        signin_btn.setOnClickListener(this);

        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.signup_btn:
                registerUser();
                break;
            case R.id.signup_login_btn:
                Intent intent = new Intent(this,LoginActivity.class);
                startActivity(intent);
                finish();
                break;
        }
    }

    private void registerUser() {
        String email = user_et.getText().toString().trim();
        String password = pswd_et.getText().toString().trim();
        String confirm_password = confirmPswd_et.getText().toString().trim();

        if(email.isEmpty()){
            user_et.setError("Email is required");
            user_et.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            user_et.setError("Please enter a valid Email");
            user_et.requestFocus();
            return;
        }
        if(password.isEmpty()){
            pswd_et.setError("Password is required");
            pswd_et.requestFocus();
            return;
        }
        if(password.length() < 6){
            pswd_et.setError("Minimum lenght of password should be 6");
            pswd_et.requestFocus();
            return;
        }
        if(!confirm_password.equals(password)){
            confirmPswd_et.setError("Password should not matched");
            confirmPswd_et.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressBar.setVisibility(View.GONE);
                if(task.isSuccessful()) {
                    Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else{
                    if(task.getException() instanceof FirebaseAuthUserCollisionException)
                        Toast.makeText(getApplicationContext(),"You are already registered",
                            Toast.LENGTH_SHORT).show();
                    else {
                        Toast.makeText(getApplicationContext(), task.getException().getMessage()
                                , Toast.LENGTH_LONG).show();
                        Log.d("Signup Exception",task.getException().getMessage());
                    }
                }
            }
        });
    }
}
